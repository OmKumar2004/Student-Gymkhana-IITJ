import React, { useState } from 'react';
import './Signup.css'; // Import the CSS file for styling

const SignUpPage = () => {
  const [form, setForm] = useState({
    username: '',
    email: '',
    rollnumber: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); // Reset error message
    setSuccessMessage(''); // Reset success message

    // Check if passwords match
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    try {
      // Use the actual backend URL here
      const response = await fetch('http://localhost:3300/apis/v1/user/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          roll_number: form.rollnumber,
          u_name: form.username,
          mail: form.email,
          pass: form.password, // Send password in the request body
        }),
      });

      // Handling based on status code
      if (response.status != 201) { // Check explicitly for 201 success status
        const errorData = await response.json();
        
        // Handle specific status codes
        switch (response.status) {
          case 400:
            throw new Error(errorData.message || 'Bad request. Please check the entered details.');
          case 409:
            throw new Error(errorData.message || 'Email or username already exists.');
          case 500:
            throw new Error('Internal server error. Please try again later.');
          default:
            throw new Error(errorData.message || 'Sign-up failed. Please try again.');
        }
      }

      const data = await response.json();
      setSuccessMessage("Sign-up successful! Please log in.");

      // Optionally, redirect or clear form on successful sign-up
      setForm({
        username: '',
        rollnumber: '',
        email: '',
        password: '',
        confirmPassword: '',
      });

      console.log('Sign-up successful:', data);
    } catch (error) {
      setError(error.message);
      console.error('Error during sign-up:', error);
    }
  };

  return (
    <div className="signup-container">
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            name="username"
            value={form.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Roll Number</label>
          <input
            type="text"
            name="rollnumber"
            value={form.rollnumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Confirm Password</label>
          <input
            type="password"
            name="confirmPassword"
            value={form.confirmPassword}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="signup-btn">Sign Up</button>
      </form>

      {error && <div className="error-message">{error}</div>}
      {successMessage && <div className="success-message">{successMessage}</div>}

      <div className="google-signup">
        <button className="google-btn">Sign Up with Google</button>
      </div>
    </div>
  );
};

export default SignUpPage;
