import React from 'react';
import './sathi.css';

const Sathi = () => {
  return (
    <div className="gallery-container">
      <h1>SATHI</h1>
      <p>Connect with Sathi</p>
    </div>
  );
};

export default Sathi;
