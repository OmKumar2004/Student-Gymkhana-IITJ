import React, { useState } from 'react';
import './Login.css';

const LoginPage = () => {
  const [form, setForm] = useState({
    usernameOrEmail: '',
    password: '',
  });
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); // Reset error message before submission

    try {
      // Use the actual backend URL here
      const response = await fetch('https://your-deployed-server.com/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed. Please check your credentials.');
      }

      const data = await response.json();
      // Store the token or session data received from the backend
      localStorage.setItem('token', data.token); // Example of storing the token for later use
      console.log('Login successful:', data);

      // Optionally, redirect or update UI on successful login
      // Example: Redirect to the home page after login
      window.location.href = './Home'; // Adjust as needed for your app structure
    } catch (error) {
      setError(error.message);
      console.error('Error during login:', error);
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Username or Email</label>
          <input
            type="text"
            name="usernameOrEmail"
            value={form.usernameOrEmail}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="login-btn">Login</button>
      </form>

      {error && <div className="error-message">{error}</div>}

      <div className="google-login">
        <button className="google-btn">Login with Google</button>
      </div>
    </div>
  );
};

export default LoginPage;
